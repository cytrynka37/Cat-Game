# Zapis dokumentacji do pliku Markdown
documentation = """
# Dokumentacja klas

## Spis treści
1. [Game](#game)
2. [Player](#player)
3. [Wizard](#wizard)
4. [Zombie](#zombie)
5. [Enemy](#enemy)
6. [Bullet](#bullet)
7. [Coin](#coin)
8. [Fish](#fish)
9. [HealthBar](#healthbar)
10. [Menu](#menu)

---

## Game

**Opis**: Klasa `Game` zarządza główną logiką gry, w tym zdrowiem gracza, monetami, pauzowaniem gry, resetowaniem sceny i kończeniem gry.

### Metody:
- `func _ready()`: Inicjalizuje stan gry, ustawia zdrowie gracza i monety, podłącza sygnały wrogów.
- `func _on_player_took_damage(amount)`: Zmniejsza zdrowie gracza o podaną ilość, aktualizuje HUD, sprawdza czy gracz stracił wszystkie punkty zdrowia.
- `func add_lifes(amount)`: Dodaje podaną ilość zdrowia graczowi, upewniając się, że nie przekracza maksymalnego zdrowia.
- `func add_coins(amount)`: Dodaje podaną ilość monet do zasobów gracza i aktualizuje HUD.
- `func _on_enemy_died()`: Dodaje monety po śmierci wroga.
- `func play_pause(screen)`: Pauzuje lub wznawia grę, wyświetla lub ukrywa podany ekran.
- `func reset(screen)`: Resetuje bieżącą scenę gry.
- `func resume(screen)`: Wznawia grę.
- `func quit()`: Zamyka grę.

---

## Player

**Opis**: Klasa `Player` zarządza ruchem gracza przy użyciu funkcji `move_and_slide` oraz wejściami użytkownika.

### Metody:
- `func _physics_process(delta)`: Aktualizuje prędkość gracza na podstawie wejść użytkownika i porusza gracza.

---

## Wizard

**Opis**: Klasa `Wizard` zarządza maną i rzucaniem zaklęć przez maga.

### Metody:
- `func cast_spell()`: Rzuca zaklęcie, zmniejsza manę o 10, wyświetla komunikat o powodzeniu lub braku many.

---

## Zombie

**Opis**: Klasa `Zombie` zarządza ruchem zombiaka, który porusza się losowo po planszy.

### Metody:
- `func _physics_process(delta)`: Aktualizuje losowy ruch zombiaka przy użyciu funkcji `move_and_slide`.

---

## Enemy

**Opis**: Klasa `Enemy` zarządza zdrowiem przeciwników oraz obsługą obrażeń.

### Metody:
- `func take_damage(amount)`: Zmniejsza zdrowie przeciwnika o podaną ilość, usuwa przeciwnika ze
